package ElectricityBillingSystem;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.Statement;

public class conn {
    Connection c;
    Statement s;

    conn() {
        try {
            c = DriverManager.getConnection("jdbc:postgresql://localhost:5432/electricitysystem", "postgres", "Shubham@187");
            s = c.createStatement();
        } catch (Exception e) {
            e.printStackTrace();
        }

    }
}
