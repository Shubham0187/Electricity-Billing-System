package ElectricityBillingSystem;

import net.proteanit.sql.DbUtils;

import javax.swing.*;
import java.awt.*;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.sql.ResultSet;

public class depositdetails extends JFrame implements ActionListener{

    JTable t1;
    JButton b1, b2;
    JLabel lblmeternumber, lblmonth;
    Choice meternumber, cmonth;
    String x[] = {"Meter Number","Month","Units","Total Bill","Status"};
    String y[][] = new String[40][8];
    int i=0, j=0;
    depositdetails(){
        super("Deposit Details");

        setSize(700,700);
        setLocation(400,100);
        setLayout(null);
        getContentPane().setBackground(Color.WHITE);

        lblmeternumber = new JLabel("Search By Meter Number");
        lblmeternumber.setBounds(20, 20, 150, 20);
        add(lblmeternumber);

        meternumber = new Choice();
        meternumber.setBounds(180, 20, 150, 20);
        add(meternumber);

        lblmonth = new JLabel("Search By Month");
        lblmonth.setBounds(400, 20, 100, 20);
        add(lblmonth);

        cmonth = new Choice();

        t1 = new JTable(y,x);

        try{
            conn c  = new conn();
            String s1 = "select * from bill";
            ResultSet rs  = c.s.executeQuery(s1);
//            while(rs.next()){
//                y[i][j++]=rs.getString("meter");
//                y[i][j++]=rs.getString("month");
//                y[i][j++]=rs.getString("units");
//                y[i][j++]=rs.getString("total_bill");
//                y[i][j++]=rs.getString("status");
//                i++;
//                j=0;
//            }
//

            t1.setModel(DbUtils.resultSetToTableModel(rs));

            String str2 = "select * from customer";
            rs = c.s.executeQuery(str2);
            while(rs.next()){
                meternumber.add(rs.getString("meter_no"));
            }


        }catch(Exception e){
            e.printStackTrace();
        }

        meternumber.setBounds(180,20, 150, 20);
        add(meternumber);


        cmonth.setBounds(520, 20, 150, 20);
        cmonth.add("January");
        cmonth.add("February");
        cmonth.add("March");
        cmonth.add("April");
        cmonth.add("May");
        cmonth.add("June");
        cmonth.add("July");
        cmonth.add("August");
        cmonth.add("September");
        cmonth.add("October");
        cmonth.add("November");
        cmonth.add("December");
        add(cmonth);


        b1 = new JButton("Search");
        b1.setBounds(20, 70, 80, 20);
        b1.addActionListener(this);
        add(b1);

        b2 = new JButton("Print");
        b2.setBounds(120, 70, 80, 20);
        b2.addActionListener(this);
        add(b2);

        JScrollPane sp = new JScrollPane(t1);
        sp.setBounds(0, 100, 700, 650);
        add(sp);

    }
    public void actionPerformed(ActionEvent ae){
        if(ae.getSource() == b1){
            String str = "select * from bill where meter_no = '"+meternumber.getSelectedItem()+"' and month = '"+cmonth.getSelectedItem()+"'";
            try{
                conn c = new conn();
                ResultSet rs = c.s.executeQuery(str);
                t1.setModel(DbUtils.resultSetToTableModel(rs));
            }catch(Exception e){}
        }else if(ae.getSource() == b2){
            try{
                t1.print();
            }catch(Exception e){}
        }
    }

    public static void main(String[] args){
        new depositdetails().setVisible(true);
    }

}


