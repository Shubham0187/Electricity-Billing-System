package ElectricityBillingSystem;

import net.proteanit.sql.DbUtils;

import javax.swing.*;
import java.awt.*;
import java.sql.ResultSet;

public class billdetails extends JFrame{

    JTable t1;
    String x[] = {"Meter Number","Month","Units","Total Bill","Status"};
    String y[][] = new String[40][8];
    int i=0, j=0;
    billdetails(String meter){
        super("Bill Details");
        setSize(700,650);

        setLocation(400,150);
        setLayout(null);
        getContentPane().setBackground(Color.WHITE);

        t1 = new JTable(y,x);

        try{
            conn c  = new conn();
            String s1 = "select * from bill where meter_no = '"+meter+"'";
            ResultSet rs  = c.s.executeQuery(s1);

            t1.setModel(DbUtils.resultSetToTableModel(rs));

        }catch(Exception e){
            e.printStackTrace();
        }


        JScrollPane sp = new JScrollPane(t1);
        sp.setBounds(0, 0, 700, 650);
        add(sp);

    }

    public static void main(String[] args){
        new billdetails("").setVisible(true);
    }

}

